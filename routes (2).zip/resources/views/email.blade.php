<h1>Hi, {{$name}}</h1>
<p>{{$content}}</p>