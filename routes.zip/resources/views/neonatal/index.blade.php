@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Neonatal</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">Neonatal</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            {{-- {!! Form::select('induk_opd_id',$induk_opd_arr,"",['class'=>'form-control daerah', 'form'=>'storeForm','required'=>'required','placeholder'=>'Pilih SKPD', 'id'=>'induk_opd']) !!}
                            <select name="program_id" form="storeForm" id="program_id" class="form-control">
                                <option value="">Pilih Program</option>
                            </select>
                            <select name="kegiatan_id" form="storeForm" id="kegiatan_id" class="form-control">
                                <option value="">Pilih Kegiatan</option>
                            </select>
                            --}}
                            <select name="tahun" id="tahun" class="form-control">
                                <option value="2024" {{app('request')->input('year') == 2024 ? "selected":""}}>2024</option>
                                <option value="2023" {{app('request')->input('year') == 2023 ? "selected":""}}>2023</option>
                            </select> 
                            <button class="btn btn-primary" id="filter">Filter</button>
                            <a type="button" class="btn btn-warning" href="{{ route('neonatal.report', ['year' => app('request')->input('year')]) }}"  target='_blank'><i class="mdi mdi-note"></i>Report</a>
                        </div>
                        {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div> --}}
                    </div>
                    {{-- <h4 class="card-title">Pengguna</h4> --}}
                    {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                    <div class="table-responsive">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr>
                                <th rowspan="3">No</th>
                                <th rowspan="3">Desa</th>
                                <th colspan="3">Jumlah Lahir Hidup</th>
                                <th colspan="6">Kunjungan Neonatal 1 kali</th>
                                <th colspan="6">Kunjungan Neonatal 3 kali (kn lengkap)</th>
                                <th colspan="6">Bayi baru lahir yang diberikan screening Hipotiroid Konginetal</th>
                                @role('Admin')
                                <th rowspan="3">Lock data</th>
                                @endrole
                            </tr>
                            <tr>
                                <th rowspan="2">Laki Laki</th>
                                <th rowspan="2">Perempuan</th>
                                <th rowspan="2">Laki Laki + Perempuan</th>
                                <th colspan="2">Laki Laki</th>
                                <th colspan="2">Perempuan</th>
                                <th colspan="2">Laki Laki + Perempuan</th>
                                <th colspan="2">Laki Laki</th>
                                <th colspan="2">Perempuan</th>
                                <th colspan="2">Laki Laki + Perempuan</th>
                                <th colspan="2">Laki Laki</th>
                                <th colspan="2">Perempuan</th>
                                <th colspan="2">Laki Laki + Perempuan</th>
                            </tr>
                            <tr>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]}}</td>
                                    
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn1_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["kn1_L"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn1_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["kn1_P"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn1_P"] + $item->neonatal_per_desa(app('request')->input('year'))["kn1_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format(($item->neonatal_per_desa(app('request')->input('year'))["kn1_P"] + $item->neonatal_per_desa(app('request')->input('year'))["kn1_L"]) / ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"])* 100, 2):0}}%</td>
                                    
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_L"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_P"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_P"] + $item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format(($item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_P"] + $item->neonatal_per_desa(app('request')->input('year'))["kn_lengkap_L"]) / ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"])* 100, 2):0}}%</td>
                                    
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["hipo_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["hipo_L"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["hipo_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] > 0?number_format($item->neonatal_per_desa(app('request')->input('year'))["hipo_P"] / $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]* 100, 2):0}}%</td>
                                    <td>{{$item->neonatal_per_desa(app('request')->input('year'))["hipo_P"] + $item->neonatal_per_desa(app('request')->input('year'))["hipo_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] > 0?number_format(($item->neonatal_per_desa(app('request')->input('year'))["hipo_P"] + $item->neonatal_per_desa(app('request')->input('year'))["hipo_L"]) / ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"])* 100, 2):0}}%</td>
                                    <td><input type="checkbox" name="lock" {{$item->neonatal_lock_get(app('request')->input('year')) == 1 ? "checked":""}} class="data-lock" id="{{$item->id}}"></td>
                                    {{-- <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_mati_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_mati_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_LP"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_mati_LP"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_mati_LP"]}}</td> --}}
                                  </tr>
                                @endforeach
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>{{$totalLahirHidupL}}</td>
                                    <td>{{$totalLahirHidupP}}</td>
                                    <td>{{$totalLahirHidupL + $totalLahirHidupP}}</td>
                                    
                                    <td>{{$totalkn1_L}}</td>
                                    <td>{{$totalLahirHidupL > 0?number_format($totalkn1_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td>{{$totalkn1_P}}</td>
                                    <td>{{$totalLahirHidupP > 0?number_format($totalkn1_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td>{{$totalkn1_L + $totalkn1_P}}</td>
                                    <td>{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalkn1_L + $totalkn1_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    
                                    <td>{{$totalkn_lengkap_L}}</td>
                                    <td>{{$totalLahirHidupL > 0?number_format($totalkn_lengkap_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td>{{$totalkn_lengkap_P}}</td>
                                    <td>{{$totalLahirHidupP > 0?number_format($totalkn_lengkap_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td>{{$totalkn_lengkap_L + $totalkn_lengkap_P}}</td>
                                    <td>{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalkn_lengkap_L + $totalkn_lengkap_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    
                                    <td>{{$totalhipo_L}}</td>
                                    <td>{{$totalLahirHidupL > 0?number_format($totalhipo_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td>{{$totalhipo_P}}</td>
                                    <td>{{$totalLahirHidupP > 0?number_format($totalhipo_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td>{{$totalhipo_L + $totalhipo_P}}</td>
                                    <td>{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalhipo_L + $totalhipo_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    <td></td>
                                </tr>
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterNeonatal(app('request')->input('year')) && $item->filterKelahiran(app('request')->input('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L}}</td>
                                    <td>{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P}}</td>
                                    <td id="lahir_L{{$item->filterKelahiran(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P}}</td>
                                    
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="kn1_L" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->kn1_L}}" class="form-control data-input" style="border: none"></td>
                                    <td id="kn1_L{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L > 0?number_format($item->filterNeonatal(app('request')->input('year'))->kn1_L/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L)*100, 2):0}}%</td>
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="kn1_P" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->kn1_P}}" class="form-control data-input" style="border: none"></td>
                                    <td id="kn1_P{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P > 0?number_format($item->filterNeonatal(app('request')->input('year'))->kn1_P/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)*100, 2):0}}%</td>
                                    <td id="jumlah_kn1_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterNeonatal(app('request')->input('year'))->kn1_L + $item->filterNeonatal(app('request')->input('year'))->kn1_P}}</td>
                                    <td id="persen_kn1_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P> 0?number_format(($item->filterNeonatal(app('request')->input('year'))->kn1_L + $item->filterNeonatal(app('request')->input('year'))->kn1_P)/(($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P))* 100, 2):0}}%</td>
                                    
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="kn_lengkap_L" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->kn_lengkap_L}}" class="form-control data-input" style="border: none"></td>
                                    <td id="kn_lengkap_L{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L > 0?number_format($item->filterNeonatal(app('request')->input('year'))->kn_lengkap_L/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L) * 100, 2):0}}%</td>
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="kn_lengkap_P" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->kn_lengkap_P}}" class="form-control data-input" style="border: none"></td>
                                    <td id="kn_lengkap_P{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P > 0?number_format($item->filterNeonatal(app('request')->input('year'))->kn_lengkap_P/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P) * 100, 2):0}}%</td>
                                    <td id="jumlah_kn_lengkap_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterNeonatal(app('request')->input('year'))->kn_lengkap_L + $item->filterNeonatal(app('request')->input('year'))->kn_lengkap_P}}</td>
                                    <td id="persen_kn_lengkap_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P> 0?number_format(($item->filterNeonatal(app('request')->input('year'))->kn_lengkap_L + $item->filterNeonatal(app('request')->input('year'))->kn_lengkap_P)/(($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}%</td>
                                    
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="hipo_L" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->hipo_L}}" class="form-control data-input" style="border: none"></td>
                                    <td id="hipo_L{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L > 0?number_format($item->filterNeonatal(app('request')->input('year'))->hipo_L/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L) * 100, 2):0}}</td>
                                    <td><input type="number" {{$item->filterNeonatal(app('request')->input('year'))->status == 1?"disabled":""}} name="hipo_P" id="{{$item->filterNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterNeonatal(app('request')->input('year'))->hipo_P}}" class="form-control data-input" style="border: none"></td>
                                    <td id="hipo_P{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P > 0?number_format($item->filterNeonatal(app('request')->input('year'))->hipo_P/($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P) * 100, 2):0}}</td>
                                    <td id="jumlah_hipo_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterNeonatal(app('request')->input('year'))->hipo_L + $item->filterNeonatal(app('request')->input('year'))->hipo_P}}</td>
                                    <td id="persen_hipo_LP{{$item->filterNeonatal(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P> 0?number_format(($item->filterNeonatal(app('request')->input('year'))->hipo_L + $item->filterNeonatal(app('request')->input('year'))->hipo_P)/(($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    {{-- <td><input type="number" name="lahir_hidup_P" id="{{$item->filterKelahiran(app('request')->input('year'))->id}}" value="{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P}}" class="form-control data-input" style="border: none"></td>
                                    <td><input type="number" name="lahir_mati_P" id="{{$item->filterKelahiran(app('request')->input('year'))->id}}" value="{{$item->filterKelahiran(app('request')->input('year'))->lahir_mati_P}}" class="form-control data-input" style="border: none"></td>
                                    <td id="lahir_P{{$item->filterKelahiran(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P + $item->filterKelahiran(app('request')->input('year'))->lahir_mati_P}}</td>
                                    <td id="lahir_hidup_LP{{$item->filterKelahiran(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L}}</td>
                                    <td id="lahir_mati_LP{{$item->filterKelahiran(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_mati_P + $item->filterKelahiran(app('request')->input('year'))->lahir_mati_L}}</td>
                                    <td id="lahir_hidup_mati_LP{{$item->filterKelahiran(app('request')->input('year'))->id}}">{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P + $item->filterKelahiran(app('request')->input('year'))->lahir_mati_P + $item->filterKelahiran(app('request')->input('year'))->lahir_mati_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L}}</td> --}}

                                  </tr>
                                  @endif
                                @endforeach
                                <tr>
                                    <td></td>
                                    <td></td>
                                    <td>{{$totalLahirHidupL}}</td>
                                    <td>{{$totalLahirHidupP}}</td>
                                    <td>{{$totalLahirHidupL + $totalLahirHidupP}}</td>
                                    
                                    <td id="kn1_L">{{$totalkn1_L}}</td>
                                    <td id="percentage_kn1_L">{{$totalLahirHidupL > 0?number_format($totalkn1_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td id="kn1_P">{{$totalkn1_P}}</td>
                                    <td id="percentage_kn1_P">{{$totalLahirHidupP > 0?number_format($totalkn1_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td id="total_kn1">{{$totalkn1_L + $totalkn1_P}}</td>
                                    <td id="percentage_total_kn1">{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalkn1_L + $totalkn1_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    
                                    <td id="kn_lengkap_L">{{$totalkn_lengkap_L}}</td>
                                    <td id="percentage_kn_lengkap_L">{{$totalLahirHidupL > 0?number_format($totalkn_lengkap_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td id="kn_lengkap_P">{{$totalkn_lengkap_P}}</td>
                                    <td id="percentage_kn_lengkap_P">{{$totalLahirHidupP > 0?number_format($totalkn_lengkap_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td id="total_kn_lengkap">{{$totalkn_lengkap_L + $totalkn_lengkap_P}}</td>
                                    <td id="percentage_total_kn_lengkap">{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalkn_lengkap_L + $totalkn_lengkap_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    
                                    <td id="hipo_L">{{$totalhipo_L}}</td>
                                    <td id="percentage_hipo_L">{{$totalLahirHidupL > 0?number_format($totalhipo_L / $totalLahirHidupL * 100, 2):0}}%</td>
                                    <td id="hipo_P">{{$totalhipo_P}}</td>
                                    <td id="percentage_hipo_P">{{$totalLahirHidupP > 0?number_format($totalhipo_P / $totalLahirHidupP * 100, 2):0}}%</td>
                                    <td id="total_hipo">{{$totalhipo_L + $totalhipo_P}}</td>
                                    <td id="percentage_total_hipo">{{$totalLahirHidupL + $totalLahirHidupP > 0?number_format(($totalhipo_L + $totalhipo_P) / ($totalLahirHidupL + $totalLahirHidupP)* 100, 2):0}}%</td>
                                    <td></td>
                                </tr>
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

<div class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="title">Tambah Program</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" value="Submit" class="btn btn-primary" id="submitButton" form="storeForm">
        </div>
        {!! Form::close() !!}
      </div>
    </div>
  </div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>
        var table = $('#datatable').DataTable({
            responsive:false,
            processing: true,
            serverSide: true,
            order: [[ 0, "asc" ]],
            ajax: {
                'url': '{{ route("datatable.sub_kegiatan") }}',
                'type': 'GET',
                'beforeSend': function (request) {
                    request.setRequestHeader("X-CSRFToken", '{{ csrf_token() }}');
                },
                data: function (d) {
                    d.kegiatan_id = $('#kegiatan_id').val();
                },
            },
            columns: [
                {data:'kode',name:'kode'},
                {data:'nama',name:'nama'},
                {data:'sasaran',name:'sasaran'},
                {data: 'indikator', name:'indikator'}
            ],
        });

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');
        let kn1_L = $(this).parent().parent().find(`#kn1_L${id}`);
        let kn1_P = $(this).parent().parent().find(`#kn1_P${id}`);
        let jumlah_kn1_LP = $(this).parent().parent().find(`#jumlah_kn1_LP${id}`);
        let persen_kn1_LP = $(this).parent().parent().find(`#persen_kn1_LP${id}`);
        let kn_lengkap_L = $(this).parent().parent().find(`#kn_lengkap_L${id}`);
        let kn_lengkap_P = $(this).parent().parent().find(`#kn_lengkap_P${id}`);
        let jumlah_kn_lengkap_LP = $(this).parent().parent().find(`#jumlah_kn_lengkap_LP${id}`);
        let persen_kn_lengkap_LP = $(this).parent().parent().find(`#persen_kn_lengkap_LP${id}`);
        let hipo_L = $(this).parent().parent().find(`#hipo_L${id}`);
        let hipo_P = $(this).parent().parent().find(`#hipo_P${id}`);
        let jumlah_hipo_LP = $(this).parent().parent().find(`#jumlah_hipo_LP${id}`);
        let persen_hipo_LP = $(this).parent().parent().find(`#persen_hipo_LP${id}`);
        // let lahir_hidup_mati_LP = $(this).parent().parent().find(`#lahir_hidup_mati_LP${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("neonatal.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                console.log(res, kn1_L);
                kn1_L.text(`${res.persen_kn1_L}%`);
                kn1_P.text(`${res.persen_kn1_P}%`);
                jumlah_kn1_LP.text(`${res.jumlah_kn1_LP}`);
                persen_kn1_LP.text(`${res.persen_kn1_LP}%`);
                kn_lengkap_L.text(`${res.persen_kn_lengkap_L}%`);
                kn_lengkap_P.text(`${res.persen_kn_lengkap_P}%`);
                jumlah_kn_lengkap_LP.text(`${res.jumlah_kn_lengkap_LP}`);
                persen_kn_lengkap_LP.text(`${res.persen_kn_lengkap_LP}%`);
                hipo_L.text(`${res.persen_hipo_L}%`);
                hipo_P.text(`${res.persen_hipo_P}%`);
                persen_hipo_LP.text(`${res.persen_hipo_LP}%`);
                jumlah_hipo_LP.text(`${res.jumlah_hipo_LP}%`);
                // lahir_hidup_mati_LP.text(`${res.lahir_hidup_mati_LP}%`);
                // kf_lengkap.text(`${res.kf_lengkap}%`);
                // vita.text(`${res.vita}%`);

                let total_column = res.column;
                $(`#total_kn1`).text(res.totalkn1_LP)
                $(`#total_kn_lengkap`).text(res.totalkn_lengkap_LP)
                $(`#total_hipo`).text(res.totalhipo_LP)
                $(`#percentage_total_kn1`).text(`${res.persenkn1_LP}%`)
                $(`#percentage_total_kn_lengkap`).text(`${res.persenkn_lengkap_LP}%`)
                $(`#percentage_total_hipo`).text(`${res.persenhipo_LP}%`)
                $(`#${total_column}`).text(res.total);
                $(`#percentage_${total_column}`).text(`${res.percentage}%`);
			}
		});
        console.log(name, value, id);
        })
        $('#induk_opd').change(function(){
            let valueOpd = $("#induk_opd").val()
            $.ajax({
                    type: "get",
                    url: `{{url('apiProgram/kegiatan')}}/${valueOpd}`,
                    success: (res) => {
                        if(res.status == 'success'){
                        let option = `<option value="">Pilih Program</option>`;

                        for(const key in res.data){
                            option += `<option value="${res.data[key].id}">${res.data[key].kode} - ${res.data[key].uraian}</option>`
                        }
                        $("#program_id").html(option)

                        } else {
                            alert(res.data);
                        }
                    }
                })
        });
        $('#program_id').change(function(){
            let program_id = $("#program_id").val()
            $.ajax({
                    type: "get",
                    url: `{{url('apiKegiatan/sub_kegiatan')}}/${program_id}`,
                    success: (res) => {
                        if(res.status == 'success'){
                        let option = `<option value="">Pilih Kegiatan</option>`;

                        for(const key in res.data){
                            option += `<option value="${res.data[key].id}">${res.data[key].kode} - ${res.data[key].uraian}</option>`
                        }
                        $("#kegiatan_id").html(option)

                        } else {
                            alert(res.data);
                        }
                    }
                })
        });
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/neonatal?year="+year;


        })
        $("#kegiatan_id").change(function(){
            table.draw()
        })
        $('.btn-tambah-program').click(function(){
            if($('#induk_opd').val() == ""){
                alert("Pilih SKPD Terlebih dahulu")
            } else {
                let valueOpd = $('#induk_opd').val();
                let stringOpd = valueOpd.toString();
                let kegiatan_id = $("#kegiatan_id").val();


                $.ajax({
                    type: "get",
                    url: `{{url('api/jabatan')}}/${valueOpd}`,
                    success: (res) => {
                        if(res.status == 'success'){
                            let template = `
                {!! Form::open(['route'=>$route.'.store','method'=>'POST', 'id'=>'storeForm']) !!}
            <div class="mb-3 row">
                <input type="hidden" name="kegiatan_id" value="${kegiatan_id}">
                <label for="name" class="col-md-2 col-form-label">Uraian</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10">
                    {!! Form::text('uraian',null,['class'=>'form-control','id'=>"nama"]) !!}
                </div>
            </div>
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Kode</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10">
                    {!! Form::number('kode',null,['class'=>'form-control','id'=>"nama"]) !!}
                </div>
            </div>     
                `
                $('.modal-body').html(template)
                $('#submitButton').attr('form', 'storeForm')
                $('#title').html('Tambah Data Sub Kegiatan');
                $('.modal').modal('toggle');
                        } else {
                            alert(res.data);
                        }
                    }
                })

            }
    });
    $('#data').on('click', '.data-lock', function(){
            let id = $(this).attr('id');
            let year = $("#tahun").val();
            $.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
            if($(this).is(':checked')){
            $.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("Neonatal.lock") }}',
			'data'	: {'id': id, 'status': 1, 'year': year},
			success	: function(res){
				console.log(res);
			}
		});
            } else {
                $.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("Neonatal.lock") }}',
			'data'	: {'id': id, 'status': 0, 'year': year},
			success	: function(res){
				console.log(res);
			}
		});
            }
        })
    $('#data').on('click', '.btn-mod2', function(){
            let id = $(this).attr('id');

            $.ajax({
                type: "get",
                url: `{{url('apiEdit/IbuHamil')}}/${id}`,
                success: (res) => {
                    console.log(res)
                    if(res.status == "success"){
                            console.log(res.data)
                            let textUraian = `<input type="text" name="k1" id="nama" class="form-control" value="${res.IbuHamil.k1}">`
                            let textKode = `<input type="text" name="k4" class="form-control" id="bezetting" value="${res.IbuHamil.k4}">`
                            let textPosyanduPurnama = `<input type="text" name="k6" class="form-control" id="bezetting" value="${res.IbuHamil.k6}">`
                            let textPosyanduMandiri = `<input type="text" name="fasyankes" class="form-control" id="bezetting" value="${res.IbuHamil.fasyankes}">`
                            let textPosyanduAktif = `<input type="text" name="kf1" class="form-control" id="bezetting" value="${res.IbuHamil.kf1}">`
                            let textPosbindu = `<input type="text" name="kf_lengkap" class="form-control" id="bezetting" value="${res.IbuHamil.kf_lengkap}">`
                            let textVita = `<input type="text" name="vita" class="form-control" id="bezetting" value="${res.IbuHamil.vita}">`


                            let template = `
                {!! Form::open(['route'=>$route.'.store','method'=>'POST', 'id'=>'EditForm']) !!}
                <input name="_method" type="hidden" value="PUT">
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">K1</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="nama_field">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">K4</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="bezettingField">
                </div>
            </div>     
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">K6</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="purnamaField">
                </div>
            </div>     
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Persalinan di Fasyankes</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="mandiriField">
                </div>
            </div>     
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Kf1</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="aktifField">
                </div>
            </div>     
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">KF Lengkap</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="posbinduField">
                </div>
            </div>     
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Ibu Bersalin Yang diberi Vitamin A</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="vitaField">
                </div>
            </div>     
                `
                $('.modal-body').html(template)
                $('#nama_field').html(textUraian)
                $('#bezettingField').html(textKode);
                $('#purnamaField').html(textPosyanduPurnama);
                $('#mandiriField').html(textPosyanduMandiri);
                $('#aktifField').html(textPosyanduAktif);
                $('#posbinduField').html(textPosbindu);
                $('#vitaField').html(textVita);
                $('#EditForm').attr('action', `/IbuHamil/${id}`)
                $('#submitButton').attr('form', 'EditForm')
                $('#title').html('Ubah data Program');

                $('.modal').modal('toggle');
                    } else {
                        alert("Ada Yang salah saat pengambilan data");
                    }
                }
            })

        })
    $('#datatable').on('click', '.btn-tambah-sasaran', function(){
            let id = $(this).attr('id');

            $.ajax({
                type: "get",
                url: `{{url('apiEdit/program')}}/${id}`,
                success: (res) => {
                    if(res.status == "success"){

                            let textUraian = `<input type="text" name="nama" id="nama" class="form-control">`
                            let template = `
                {!! Form::open(['route'=>'sasaran_sub_kegiatan.store','method'=>'POST', 'id'=>'storeForm']) !!}
                <input type="hidden" name="sub_kegiatan_id" value="${id}">
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Nama</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="nama_field">
                </div>
            </div>  
                `
                $('.modal-body').html(template)
                $('#nama_field').html(textUraian)
                $('#submitButton').attr('form', 'storeForm')
                $('#title').html('Tambah Data Sasaran');

                $('.modal').modal('toggle');
                    } else {
                        alert("Ada Yang salah saat pengambilan data");
                    }
                }
            })

        })
        $('#datatable').on('click', '.btn-edit-sasaran', function(){
            let id = $(this).attr('id');

            $.ajax({
                type: "get",
                url: `{{url('apiEdit/sasaran_sub_kegiatan')}}/${id}`,
                success: (res) => {
                    if(res.status == "success"){

                            let textNama = `<input type="text" name="nama" id="nama" class="form-control" value="${res.data.nama}">`
                            let template = `
                {!! Form::open(['route'=>'sasaranKegiatan.store','method'=>'POST', 'id'=>'EditForm']) !!}
                <input name="_method" type="hidden" value="PUT">
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Uraian</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="nama_field">
                </div>
            </div> 
                `
                $('.modal-body').html(template)
                $('#nama_field').html(textNama)
                $('#EditForm').attr('action', `/sasaran_sub_kegiatan/${id}`)
                $('#submitButton').attr('form', 'EditForm')
                $('#title').html('Ubah data Sasaran Kegiatan');
                $('.modal').modal('toggle');
                    } else {
                        alert("Ada Yang salah saat pengambilan data");
                    }
                }
            })

        })
        $('#datatable').on('click', '.btn-tambah-indikator', function(){
            let id = $(this).attr('id');

            $.ajax({
                type: "get",
                url: `{{url('apiEdit/sasaranProgram')}}/${id}`,
                success: (res) => {
                    if(res.status == "success"){

                            let textNama = `<input type="text" name="nama" id="nama" class="form-control">`
                            let template = `
                {!! Form::open(['route'=>'indikator_sub_kegiatan.store','method'=>'POST', 'id'=>'storeForm']) !!}
                <input type="hidden" name="sasaran_sub_kegiatan_id" value="${id}">
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Nama</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="nama_field">
                </div>
            </div>  
                `
                $('.modal-body').html(template)
                $('#nama_field').html(textNama)
                $('#title').html('Tambah Data Indikator');
                $('#submitButton').attr('form', 'storeForm')
                $('.modal').modal('toggle');
                    } else {
                        alert("Ada Yang salah saat pengambilan data");
                    }
                }
            })

        })
        $('#datatable').on('click', '.btn-edit-indikator', function(){
            let id = $(this).attr('id');

            $.ajax({
                type: "get",
                url: `{{url('apiEdit/indikator_sub_kegiatan')}}/${id}`,
                success: (res) => {
                    if(res.status == "success"){

                            let textNama = `<input type="text" name="nama" id="nama" class="form-control" value="${res.data.nama}">`
                            let template = `
                {!! Form::open(['route'=>'indikator_sub_kegiatan.store','method'=>'POST', 'id'=>'EditForm']) !!}
                <input name="_method" type="hidden" value="PUT">
            <div class="mb-3 row">
                <label for="name" class="col-md-2 col-form-label">Uraian</label>
            </div>
            <div class="mb-3 row">
                <div class="col-md-10" id="nama_field">
                </div>
            </div> 
                `
                $('.modal-body').html(template)
                $('#nama_field').html(textNama)
                $('#EditForm').attr('action', `/indikator_sub_kegiatan/${id}`)
                $('#submitButton').attr('form', 'EditForm')
                $('#title').html('Ubah data Indikator Sub Kegiatan');
                $('.modal').modal('toggle');
                    } else {
                        alert("Ada Yang salah saat pengambilan data");
                    }
                }
            })

        })
    </script>
@endpush
@endsection