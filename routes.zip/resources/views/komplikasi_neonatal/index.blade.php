@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Ibu Hamil dan Bersalin</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">Ibu Hamil dan Bersalin</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            {{-- {!! Form::select('induk_opd_id',$induk_opd_arr,"",['class'=>'form-control daerah', 'form'=>'storeForm','required'=>'required','placeholder'=>'Pilih SKPD', 'id'=>'induk_opd']) !!}
                            <select name="program_id" form="storeForm" id="program_id" class="form-control">
                                <option value="">Pilih Program</option>
                            </select>
                            <select name="kegiatan_id" form="storeForm" id="kegiatan_id" class="form-control">
                                <option value="">Pilih Kegiatan</option>
                            </select>
                            --}}
                            <select name="tahun" id="tahun" class="form-control">
                                <option value="2024" {{app('request')->input('year') == 2024 ? "selected":""}}>2024</option>
                            </select> 
                            <button class="btn btn-primary" id="filter">Submit</button>
                        </div>
                        {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div> --}}
                    </div>
                    {{-- <h4 class="card-title">Pengguna</h4> --}}
                    {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                    <div class="table-responsive">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr style="width: 100%">
                                <th rowspan="3">No</th>
                                @role("Admin")
                                <th rowspan="3">Puskesmas</th>
                                @endrole
                                @role("Puskesmas|Pihak Wajib Pajak")
                                <th rowspan="3">Desa</th>
                                @endrole
                                <th colspan="3" rowspan="2">Jumlah Lahir Hidup</th>
                                <th colspan="3" rowspan="2">Perkiraan Neonatal Komplikasi</th>
                                <th colspan="16">Jumlah Komplikasi Pada Neonatus</th>
                            </tr>
                            <tr>
                                <th colspan="2">BBLR</th>
                                <th colspan="2">Asfiksia</th>
                                <th colspan="2">Infeksi</th>
                                <th colspan="2">Tetanus Neonatorum</th>
                                <th colspan="2">Kelainan Konginetal</th>
                                <th colspan="2">Covid-19</th>
                                <th colspan="2">Lain-lain</th>
                                <th colspan="2">Total</th>
                            </tr>
                            <tr>
                                <th>L</th>
                                <th>P</th>
                                <th>L+P</th>
                                <th>L</th>
                                <th>P</th>
                                <th>L+P</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>
                                <th>jumlah</th>
                                <th>%</th>

                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]}}</td>
                                    <td>{{$item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"]}}</td>
                                    
                                    <td>{{number_format((15/100) * $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"], 2)}}</td>
                                    <td>{{number_format((15/100) * $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"], 2)}}</td>
                                    <td>{{number_format((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"]), 2)}}</td>
                                
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['bblr']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['bblr']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['asfiksia']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['asfiksia']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['infeksi']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['infeksi']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['tetanus']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['tetanus']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['kelainan']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['kelainan']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['covid_19']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['covid_19']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['lain_lain']}}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['lain_lain']/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_neonatal_per_desa(app('request')->input('year'))['lain_lain']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['covid_19']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['kelainan']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['tetanus']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['infeksi']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['asfiksia']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['bblr']
                                        }}</td>
                                    <td>{{(15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])>0?number_format(($item->komplikasi_neonatal_per_desa(app('request')->input('year'))['lain_lain']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['covid_19']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['kelainan']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['tetanus']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['infeksi']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['asfiksia']
                                        + $item->komplikasi_neonatal_per_desa(app('request')->input('year'))['bblr'])/((15/100) * ($item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(app('request')->input('year'))["lahir_hidup_P"])) * 100, 2):0}}</td>       
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterPenyebabKematianIbu(app('request')->input('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    
                                    <td>{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L}}</td>

                                    <td>{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P}}</td>

                                    <td>{{$item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L}}</td>
                                    
                                    <td>{{number_format((15/100) * $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L, 2)}}</td>
                                    
                                    <td>{{number_format((15/100) * $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P, 2)}}</td>
                                    
                                    <td>{{number_format((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P), 2)}}</td>

                                    
                                    <td><input type="number" name="bblr" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->bblr}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="bblr{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->bblr/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="asfiksia" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->asfiksia}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="asfiksia{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->asfiksia/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    
                                    <td><input type="number" name="infeksi" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->infeksi}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="infeksi{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->infeksi/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    
                                    <td><input type="number" name="tetanus" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->tetanus}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="tetanus{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->tetanus/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="kelainan" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->kelainan}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="kelainan{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->kelainan/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    
                                    <td><input type="number" name="covid_19" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->covid_19}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="covid_19{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->covid_19/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="lain_lain" id="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->lain_lain}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="lain_lain{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format($item->filterKomplikasiNeonatal(app('request')->input('year'))->lain_lain/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                    <td id="total{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->lain_lain 
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->covid_19
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->kelainan
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->tetanus
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->infeksi
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->asfiksia
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->bblr
                                        }}</td>

                                        <td id="persen_total{{$item->filterKomplikasiNeonatal(app('request')->input('year'))->id}}">{{(15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)>0?number_format(($item->filterKomplikasiNeonatal(app('request')->input('year'))->lain_lain 
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->covid_19
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->kelainan
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->tetanus
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->infeksi
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->asfiksia
                                        + $item->filterKomplikasiNeonatal(app('request')->input('year'))->bblr)/((15/100) * ($item->filterKelahiran(app('request')->input('year'))->lahir_hidup_L
                                     + $item->filterKelahiran(app('request')->input('year'))->lahir_hidup_P)) * 100, 2):0}}</td>
                                    
                                  </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');
        
        let persen_total = $(this).parent().parent().find(`#persen_total${id}`);
        let total = $(this).parent().parent().find(`#total${id}`);
        let bblr = $(this).parent().parent().find(`#bblr${id}`);
        let asfiksia = $(this).parent().parent().find(`#asfiksia${id}`);
        let infeksi = $(this).parent().parent().find(`#infeksi${id}`);
        let tetanus = $(this).parent().parent().find(`#tetanus${id}`);
        let kelainan = $(this).parent().parent().find(`#kelainan${id}`);
        let covid_19 = $(this).parent().parent().find(`#covid_19${id}`);
        let lain_lain = $(this).parent().parent().find(`#lain_lain${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("KomplikasiNeonatal.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                persen_total.text(`${res.persen_total}`);
                total.text(`${res.total}`);
                bblr.text(`${res.bblr}`);
                asfiksia.text(`${res.asfiksia}`);
                infeksi.text(`${res.infeksi}`);
                tetanus.text(`${res.tetanus}`);
                covid_19.text(`${res.kelainan}`);
                lain_lain.text(`${res.lain_lain}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    </script>
@endpush
@endsection