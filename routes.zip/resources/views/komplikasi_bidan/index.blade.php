@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Ibu Hamil dan Bersalin</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">Ibu Hamil dan Bersalin</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            {{-- {!! Form::select('induk_opd_id',$induk_opd_arr,"",['class'=>'form-control daerah', 'form'=>'storeForm','required'=>'required','placeholder'=>'Pilih SKPD', 'id'=>'induk_opd']) !!}
                            <select name="program_id" form="storeForm" id="program_id" class="form-control">
                                <option value="">Pilih Program</option>
                            </select>
                            <select name="kegiatan_id" form="storeForm" id="kegiatan_id" class="form-control">
                                <option value="">Pilih Kegiatan</option>
                            </select>
                            --}}
                            <select name="tahun" id="tahun" class="form-control">
                                <option value="2024" {{app('request')->input('year') == 2024 ? "selected":""}}>2024</option>
                            </select> 
                            <button class="btn btn-primary" id="filter">Submit</button>
                        </div>
                        {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div> --}}
                    </div>
                    {{-- <h4 class="card-title">Pengguna</h4> --}}
                    {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                    <div class="table-responsive">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr style="width: 100%">
                                <th rowspan="2">No</th>
                                @role("Admin")
                                <th rowspan="2">Puskesmas</th>
                                @endrole
                                @role("Puskesmas|Pihak Wajib Pajak")
                                <th rowspan="2">Desa</th>
                                @endrole
                                <th rowspan="2">Jumlah Ibu Hamil</th>
                                <th rowspan="2">Perkiraan Ibu Hamil Dengan Komplikasi Kebidanan</th>
                                <th colspan="2">Bumil Dengan Komplikasi Kebidanan yang ditangani</th>
                                <th colspan="11">Jumlah Komplikasi Kebidanan</th>
                                <th rowspan="2">Jumlah Komplikasi Dalam Kehamilan</th>
                                <th rowspan="2">Jumlah Komplikasi Dalam Persalinan</th>
                                <th rowspan="2">Jumlah Komplikasi Pasca Persalinan (Nifas)</th>
                            </tr>
                            <tr>
                                <th style="white-space: nowrap">Jumlah</th>
                                <th style="white-space: nowrap">%</th>
                                <th style="white-space: nowrap;">Kurang Energi Kronis (KEK)</th>
                                <th>Anemia</th>
                                <th>Pendarahan</th>
                                <th>Tuberkulosis</th>
                                <th>Malaria</th>
                                <th>Infeksi Lainnya</th>
                                <th>Preklampsia/Eklampsia</th>
                                <th>Diabetes Melitus</th>
                                <th>Jantung</th>
                                <th>Covid-19</th>
                                <th>Penyebab Lainnya</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"]}}</td>
                                    <td>{{number_format((20/100) * $item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"], 2)}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["jumlah"]}}</td>
                                    <td>{{(20/100) * $item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"]>0?number_format($item->komplikasi_bidan_per_desa(app('request')->input('year'))["jumlah"]/((20/100) * $item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"]) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["kek"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["anemia"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["pendarahan"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["tuberkulosis"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["malaria"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["infeksi_lain"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["preklampsia"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["diabetes"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["jantung"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["covid_19"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["penyebab_lain"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["komplikasi_hamil"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["komplikasi_persalinan"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(app('request')->input('year'))["komplikasi_nifas"]}}</td>
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterPenyebabKematianIbu(app('request')->input('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    
                                    <td>{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil}}</td>
                                    <td>{{number_format((20/100) * $item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil, 2)}}</td>

                                    <td><input type="number" name="jumlah" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->jumlah}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="persen_jumlah{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}">{{(20/100) * $item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil>0?number_format($item->filterKomplikasiBidan(app('request')->input('year'))->jumlah/((20/100) * $item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="kek" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->kek}}" class="form-control data-input" style="border: none; width: 100%"></td>

                                    <td><input type="number" name="anemia" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->anemia}}" class="form-control data-input" style="border: none"></td>

                                    <td><input type="number" name="pendarahan" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->pendarahan}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="tuberkulosis" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->tuberkulosis}}" class="form-control data-input" style="border: none"></td>

                                    <td><input type="number" name="malaria" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->malaria}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="infeksi_lain" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->infeks_lain}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="preklampsia" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->preklampsia}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="diabetes" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->diabetes}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="jantung" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->jantung}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="covid_19" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->covid_19}}" class="form-control data-input" style="border: none"></td>
                                   
                                    <td><input type="number" name="penyebab_lain" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->penyebab_lain}}" class="form-control data-input" style="border: none"></td>
                                   
                                    <td><input type="number" name="komplikasi_hamil" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->komplikasi_hamil}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="komplikasi_persalinan" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->komplikasi_persalinan}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="komplikasi_nifas" id="{{$item->filterKomplikasiBidan(app('request')->input('year'))->id}}" value="{{$item->filterKomplikasiBidan(app('request')->input('year'))->komplikasi_nifas}}" class="form-control data-input" style="border: none"></td>
                                    
                                  </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');
        
        let persen_jumlah = $(this).parent().parent().find(`#persen_jumlah${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("KomplikasiBidan.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                persen_jumlah.text(`${res.persen_jumlah}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    </script>
@endpush
@endsection