<button class="btn btn-sm btn-primary m-2 btn-va" link="{{route('req.va',$data->id)}}" title="PEMBAYARAN QRIS BANK KALTIMTARA" types="QRIS">Pembayaran QRIS</button>

<button class="btn btn-sm btn-success m-2 btn-va" link="{{route('req.va',$data->id)}}" title="PEMBAYARAN VIRTUAL ACCOUNT BANK KALTIMTARA" types="Virtual Account">Pembayaran VA</button>
