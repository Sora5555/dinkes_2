<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Table65 extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    public function Desa(){
        return $this->belongsTo(Desa::class);
    }

    public function PenderitaKusta($id) {
        $PenderitaKusta = Table64::where('desa_id', $id)->first();
        // dd($id, $PenderitaKusta);

        return $PenderitaKusta->l_pb + $PenderitaKusta->p_pb + $PenderitaKusta->l_mb + $PenderitaKusta->p_mb;
    }
}
