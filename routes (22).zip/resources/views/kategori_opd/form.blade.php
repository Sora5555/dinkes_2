 <div class="mb-3 row">
    <label for="name" class="col-md-2 col-form-label">Nama Kategori</label>
</div>
<div class="mb-3 row">
    <div class="col-md-10">
        {!! Form::text('nama',null,['class'=>'form-control','id'=>'nama_daerah']) !!}    
    </div>
</div>