@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               <h4 class="mb-sm-0">{{$title}}</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">{{$title}}</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            <select name="tahun" id="tahun" class="form-control">
                                <option value="2024" {{app('request')->input('year') == 2024 ? "selected":""}}>2024</option>
                            </select> 
                            {{-- <select name="month" id="month" class="form-control">
                                <option value="1" {{app('request')->input('month') == 1 ? "selected":""}}>Januari</option>
                                <option value="2" {{app('request')->input('month') == 2 ? "selected":""}}>Februari</option>
                                <option value="3" {{app('request')->input('month') == 3 ? "selected":""}}>Maret</option>
                            </select>  --}}
                            <button class="btn btn-primary" id="filter">Filter</button>
                            <a type="button" class="btn btn-warning" href="{{ route('IbuHamil.report', ['year' => app('request')->input('year')]) }}"  target='_blank'><i class="mdi mdi-note"></i>Report</a>
                        </div>
                        {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div> --}}
                    </div>
                    {{-- <h4 class="card-title">Pengguna</h4> --}}
                    {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                    <div class="table-responsive">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr>
                                <th rowspan="3">No</th>
                                @role("Admin")
                                <th rowspan="3">Puskesmas</th>
                                @endrole
                                @role("Puskesmas")
                                <th rowspan="3">Desa</th>
                                @endrole
                                <th rowspan="3">Jumlah Ibu Hamil</th>
                                <th colspan="12">IMUNISASI Td PADA IBU HAMIL</th>
                            </tr>
                            <tr>
                                <th colspan="2">Td1</th>
                                <th colspan="2">Td2</th>
                                <th colspan="2">Td3</th>
                                <th colspan="2">Td4</th>
                                <th colspan="2">Td5</th>
                                <th colspan="2">Td2+</th>
                            </tr>
                            <tr>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin|superadmin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td1"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td1"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td1"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td2"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td2"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td3"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td3"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td4"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td4"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td5"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td5"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["td2_plus"]}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] > 0?number_format($item->ibu_hamil_per_desa(app('request')->input('year'))["td2_plus"]/$item->ibu_hamil_per_desa(app('request')->input('year'))["jumlah_ibu_hamil"] * 100, 2):0}}</td>
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterDesa(app('request')->input('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    
                                    <td>{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil}}</td>
                                    
                                    <td><input type="number" name="td1" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td1}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td1{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td1/($item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil))*100, '2'):0}}%</td>
                                    
                                    <td><input type="number" name="td2" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td2}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td2{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td2/$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 100, '2'):0}}%</td>
                                    
                                    <td><input type="number" name="td3" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td3}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td3{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td3/$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 100, '2'):0}}%</td>
                                    
                                    <td><input type="number" name="td4" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td4}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td4{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td4/$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 100, '2'):0}}%</td>
                                    
                                    <td><input type="number" name="td5" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td5}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td5{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td5/$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 100, '2'):0}}%</td>
                                    
                                    <td><input type="number" name="td2_plus" id="{{$item->filterDesa(app('request')->input('year'))->id}}" value="{{$item->filterDesa(app('request')->input('year'))->td2_plus}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="td2_plus{{$item->filterDesa(app('request')->input('year'))->id}}">{{$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil > 0 ? number_format(($item->filterDesa(app('request')->input('year'))->td2_plus/$item->filterDesa(app('request')->input('year'))->jumlah_ibu_hamil) * 10, '2'):0}}%</td>
                                    
                                  </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

<div class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="title">Tambah Program</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" value="Submit" class="btn btn-primary" id="submitButton" form="storeForm">
        </div>
        {!! Form::close() !!}
      </div>
    </div>
  </div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');
        let td1 = $(this).parent().parent().find(`#td1${id}`);
        let td2 = $(this).parent().parent().find(`#td2${id}`);
        let td3 = $(this).parent().parent().find(`#td3${id}`);
        let td4 = $(this).parent().parent().find(`#td4${id}`);
        let td5 = $(this).parent().parent().find(`#td5${id}`);
        let td2_plus = $(this).parent().parent().find(`#td2_plus${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("ImunBumil.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                td1.text(`${res.td1}%`);
                td2.text(`${res.td2}%`);
                td3.text(`${res.td3}%`);
                td4.text(`${res.td4}%`);
                td5.text(`${res.td5}%`);
                td2_plus.text(`${res.td2_plus}%`);
			}
		});
        
        console.log(name, value, id, params);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            let month = $("#month").val();
            window.location.href = "/IbuHamil?year="+year+"&month="+month;


        })
    </script>
@endpush
@endsection