@extends('layouts.app')

@section('content')
<div class="container-fluid">
    @include('layouts.includes.sticky-table')

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               <h4 class="mb-sm-0">{{$title}}</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">{{$title}}</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                        </div>
                    </div>
                    <div class="table-responsive lock-header">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr style="width: 100%">
                                <th rowspan="3">No</th>
                                <th rowspan="3">Kecamatan</th>
                                @role('Admin|superadmin')
                                <th rowspan="3">Puskesmas</th>
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                <th rowspan="3">Desa</th>
                                @endrole
                                <th colspan="3" rowspan="2">Jumlah Catin terdaftar di KUA atau lembaga Agama Lainnya</th>
                                <th colspan="6" >Catin Mendapatkan Layanan Kesehatan</th>
                                <th colspan="2" rowspan="2">Catin Perempuan Anemia</th>
                                <th colspan="2" rowspan="2">Catin Perempuan Gizi Kurang</th>
                            </tr>
                            <tr>
                                <th colspan="2">Laki-Laki</th>
                                <th colspan="2">Perempuan</th>
                                <th colspan="2">Laki-Laki + Perempuan</th>
                            </tr>
                            <tr>
                                <th>Laki-Laki</th>
                                <th>Perempuan</th>
                                <th>Laki-Laki + Perempuan</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                                <th>Jumlah</th>
                                <th>%</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin|superadmin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"] + $item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"]}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_L')["total"]
                                        /$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"] * 100, 2
                                        ):0}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"]
                                        /$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"] * 100, 2
                                        ):0}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] + $item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"] + $item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"] > 0?
                                        number_format(($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] + $item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_L')["total"])
                                        /($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_L')["total"] + $item->unitKerjaAmbil('filterCatin', Session::get('year'), 'kua_P')["total"]) * 100, 2
                                        ):0}}</td>

                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'anemia')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] > 0?
                                    number_format($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'anemia')["total"]
                                    /$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] * 100, 2
                                    ):0}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'gizi')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] > 0?
                                    number_format($item->unitKerjaAmbil('filterCatin', Session::get('year'), 'gizi')["total"]
                                    /$item->unitKerjaAmbil('filterCatin', Session::get('year'), 'layanan_P')["total"] * 100, 2
                                    ):0}}</td>
                                    
                                    
                                    
                                    
                                    
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterPenyebabKematianIbu(Session::get('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->UnitKerja->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    <td><input type="number" name="kua_L" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->kua_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td><input type="number" name="kua_P" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->kua_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="kua{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->kua_P + $item->filterCatin(Session::get('year'))->kua_L}}</td>

                                    <td><input type="number" name="layanan_L" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->layanan_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="layanan_L{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->kua_L>0?
                                        number_format($item->filterCatin(Session::get('year'))->layanan_L
                                        /$item->filterCatin(Session::get('year'))->kua_L * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="layanan_P" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->layanan_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="layanan_P{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->kua_P>0?
                                        number_format($item->filterCatin(Session::get('year'))->layanan_P
                                        /$item->filterCatin(Session::get('year'))->kua_P * 100, 2):0}}</td>
                                    
                                    <td id="layanan_LP{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->layanan_P + $item->filterCatin(Session::get('year'))->layanan_L}}</td>

                                    <td id="persen_layanan_LP{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->kua_P + $item->filterCatin(Session::get('year'))->kua_L>0?
                                        number_format(($item->filterCatin(Session::get('year'))->layanan_P + $item->filterCatin(Session::get('year'))->layanan_L)
                                        /( $item->filterCatin(Session::get('year'))->kua_L + $item->filterCatin(Session::get('year'))->kua_P) * 100, 2):0}}</td>

                                    <td><input type="number" name="anemia" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->anemia}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="anemia{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->layanan_P>0?
                                    number_format($item->filterCatin(Session::get('year'))->anemia
                                    /$item->filterCatin(Session::get('year'))->layanan_P * 100, 2):0}}</td>
                                   
                                   <td><input type="number" name="gizi" id="{{$item->filterCatin(Session::get('year'))->id}}" value="{{$item->filterCatin(Session::get('year'))->gizi}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="gizi{{$item->filterCatin(Session::get('year'))->id}}">{{$item->filterCatin(Session::get('year'))->layanan_P>0?
                                    number_format($item->filterCatin(Session::get('year'))->gizi
                                    /$item->filterCatin(Session::get('year'))->layanan_P * 100, 2):0}}</td>
                                </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');

        let kua = $(this).parent().parent().find(`#kua${id}`);
        let layanan_L = $(this).parent().parent().find(`#layanan_L${id}`);
        let layanan_P = $(this).parent().parent().find(`#layanan_P${id}`);
        let layanan_LP = $(this).parent().parent().find(`#layanan_LP${id}`);
        let persen_layanan_LP = $(this).parent().parent().find(`#persen_layanan_LP${id}`);
        let anemia = $(this).parent().parent().find(`#anemia${id}`);
        let gizi = $(this).parent().parent().find(`#gizi${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("Catin.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                kua.text(`${res.kua}`);
                layanan_L.text(`${res.layanan_L}`);
                layanan_P.text(`${res.layanan_P}`);
                layanan_LP.text(`${res.layanan_LP}`);
                persen_layanan_LP.text(`${res.persen_layanan_LP}`);
                anemia.text(`${res.anemia}`);
                gizi.text(`${res.gizi}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    </script>
@endpush
@endsection