@extends('layouts.app')

@section('content')
<div class="container-fluid">
    @include('layouts.includes.sticky-table')

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               <h4 class="mb-sm-0">{{$title}}</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">{{$title}}</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                        </div>
                    </div>
                    <div class="table-responsive lock-header">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr style="width: 100%">
                                <th rowspan="2">No</th>
                                <th rowspan="2">Kecamatan</th>
                                @role('Admin|superadmin')
                                <th rowspan="2">Puskesmas</th>
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                <th rowspan="2">Desa</th>
                                @endrole
                                <th rowspan="2">Jumlah Ibu Hamil</th>
                                <th rowspan="2">Perkiraan Ibu Hamil Dengan Komplikasi Kebidanan</th>
                                <th colspan="2">Bumil Dengan Komplikasi Kebidanan yang ditangani</th>
                                <th colspan="11">Jumlah Komplikasi Kebidanan</th>
                                <th rowspan="2">Jumlah Komplikasi Dalam Kehamilan</th>
                                <th rowspan="2">Jumlah Komplikasi Dalam Persalinan</th>
                                <th rowspan="2">Jumlah Komplikasi Pasca Persalinan (Nifas)</th>
                            </tr>
                            <tr>
                                <th style="white-space: nowrap">Jumlah</th>
                                <th style="white-space: nowrap">%</th>
                                <th style="white-space: nowrap;">Kurang Energi Kronis (KEK)</th>
                                <th>Anemia</th>
                                <th>Pendarahan</th>
                                <th>Tuberkulosis</th>
                                <th>Malaria</th>
                                <th>Infeksi Lainnya</th>
                                <th>Preklampsia/Eklampsia</th>
                                <th>Diabetes Melitus</th>
                                <th>Jantung</th>
                                <th>Covid-19</th>
                                <th>Penyebab Lainnya</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin|superadmin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    <td>{{$item->ibu_hamil_per_desa(Session::get('year'))["jumlah_ibu_hamil"]}}</td>
                                    <td>{{number_format((20/100) * $item->ibu_hamil_per_desa(Session::get('year'))["jumlah_ibu_hamil"], 2)}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["jumlah"]}}</td>
                                    <td>{{(20/100) * $item->ibu_hamil_per_desa(Session::get('year'))["jumlah_ibu_hamil"]>0?number_format($item->komplikasi_bidan_per_desa(Session::get('year'))["jumlah"]/((20/100) * $item->ibu_hamil_per_desa(Session::get('year'))["jumlah_ibu_hamil"]) * 100, 2):0}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["kek"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["anemia"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["pendarahan"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["tuberkulosis"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["malaria"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["infeksi_lain"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["preklampsia"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["diabetes"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["jantung"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["covid_19"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["penyebab_lain"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["komplikasi_hamil"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["komplikasi_persalinan"]}}</td>
                                    <td>{{$item->komplikasi_bidan_per_desa(Session::get('year'))["komplikasi_nifas"]}}</td>
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterPenyebabKematianIbu(Session::get('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->UnitKerja->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    
                                    <td>{{$item->filterDesa(Session::get('year'))->jumlah_ibu_hamil}}</td>
                                    <td>{{number_format((20/100) * $item->filterDesa(Session::get('year'))->jumlah_ibu_hamil, 2)}}</td>

                                    <td><input type="number" name="jumlah" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->jumlah}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="persen_jumlah{{$item->filterKomplikasiBidan(Session::get('year'))->id}}">{{(20/100) * $item->filterDesa(Session::get('year'))->jumlah_ibu_hamil>0?number_format($item->filterKomplikasiBidan(Session::get('year'))->jumlah/((20/100) * $item->filterDesa(Session::get('year'))->jumlah_ibu_hamil) * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="kek" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->kek}}" class="form-control data-input" style="border: none; width: 100%"></td>

                                    <td><input type="number" name="anemia" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->anemia}}" class="form-control data-input" style="border: none"></td>

                                    <td><input type="number" name="pendarahan" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->pendarahan}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="tuberkulosis" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->tuberkulosis}}" class="form-control data-input" style="border: none"></td>

                                    <td><input type="number" name="malaria" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->malaria}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="infeksi_lain" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->infeks_lain}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="preklampsia" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->preklampsia}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="diabetes" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->diabetes}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="jantung" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->jantung}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="covid_19" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->covid_19}}" class="form-control data-input" style="border: none"></td>
                                   
                                    <td><input type="number" name="penyebab_lain" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->penyebab_lain}}" class="form-control data-input" style="border: none"></td>
                                   
                                    <td><input type="number" name="komplikasi_hamil" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->komplikasi_hamil}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="komplikasi_persalinan" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->komplikasi_persalinan}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="komplikasi_nifas" id="{{$item->filterKomplikasiBidan(Session::get('year'))->id}}" value="{{$item->filterKomplikasiBidan(Session::get('year'))->komplikasi_nifas}}" class="form-control data-input" style="border: none"></td>
                                    
                                  </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let id = $(this).attr('id');
        
        let persen_jumlah = $(this).parent().parent().find(`#persen_jumlah${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("KomplikasiBidan.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id},
			success	: function(res){
                persen_jumlah.text(`${res.persen_jumlah}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    </script>
@endpush
@endsection