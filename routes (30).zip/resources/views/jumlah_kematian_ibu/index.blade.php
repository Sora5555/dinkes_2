@extends('layouts.app')

@section('content')
<div class="container-fluid">
    @include('layouts.includes.sticky-table')

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               <h4 class="mb-sm-0">{{$title}}</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">{{$title}}</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            <a type="button" class="btn btn-primary" href="{{ route('JumlahKematianIbu.add', ['year' => Session::get('year')]) }}"><i class="mdi mdi-plus"></i>Add</a>
                        </div>
                           
                    </div>
                    <div class="table-responsive lock-header">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr>
                                <th rowspan="3">No</th>
                                <th rowspan="3">Kecamatan</th>
                                    @role('Admin|superadmin')
                                    <th rowspan="3">Puskesmas</th>
                                    @endrole
                                    @role('Puskesmas|Pihak Wajib Pajak')
                                    <th rowspan="3">Desa</th>
                                    @endrole
                                <th rowspan="2">Jumlah Lahir Hidup</th>
                                <th colspan="4">Kematian Ibu</th>
                            </tr>
                            <tr>
                                <th>Jumlah kematian Ibu Hamil</th>
                                <th>Jumlah Kematian Ibu Bersalin</th>
                                <th>Jumlah Kematian Ibu Nifas</th>
                                <th>Jumlah Kematian Ibu</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin|superadmin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    <td>{{$item->kelahiran_per_desa(Session::get('year'))["lahir_hidup_L"] + $item->kelahiran_per_desa(Session::get('year'))["lahir_hidup_P"]}}</td>
                                    <td>{{$item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_hamil"]}}</td>
                                    <td>{{$item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_bersalin"]}}</td>
                                    <td>{{$item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_nifas"]}}</td>
                                    <td>{{$item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_nifas"] + $item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_bersalin"] + $item->kematian_ibu_per_desa(Session::get('year'))["jumlah_kematian_ibu_hamil"]}}</td>
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterKematianIbu(Session::get('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->UnitKerja->kecamatan}}</td>
                                    <td class="unit_kerja">{{$item->nama}}</td>
                                    <td>{{$item->filterKelahiran(Session::get('year'))->lahir_hidup_L + $item->filterKelahiran(Session::get('year'))->lahir_hidup_P}}</td>
                                    <td><input type="number" name="jumlah_kematian_ibu_hamil" id="{{$item->filterKematianIbu(Session::get('year'))->id}}" value="{{$item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_hamil}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="jumlah_kematian_ibu_bersalin" id="{{$item->filterKematianIbu(Session::get('year'))->id}}" value="{{$item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_bersalin}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td><input type="number" name="jumlah_kematian_ibu_nifas" id="{{$item->filterKematianIbu(Session::get('year'))->id}}" value="{{$item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_nifas}}" class="form-control data-input" style="border: none"></td>
                                    
                                    <td id="total{{$item->filterKematianIbu(Session::get('year'))->id}}">{{$item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_hamil + $item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_bersalin + $item->filterKematianIbu(Session::get('year'))->jumlah_kematian_ibu_nifas}}</td>

                                  </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let id = $(this).attr('id');
        let total = $(this).parent().parent().find(`#total${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("JumlahKematianIbu.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id},
			success	: function(res){
                total.text(`${res.total}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    $('#data').on('click', '.data-lock', function(){
            let id = $(this).attr('id');
            let year = $("#tahun").val();
            $.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
            if($(this).is(':checked')){
            $.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("Kelahiran.lock") }}',
			'data'	: {'id': id, 'status': 1, 'year': year},
			success	: function(res){
				console.log(res);
			}
		});
            } else {
                $.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("Kelahiran.lock") }}',
			'data'	: {'id': id, 'status': 0, 'year': year},
			success	: function(res){
				console.log(res);
			}
		});
            }
        })
    </script>
@endpush
@endsection