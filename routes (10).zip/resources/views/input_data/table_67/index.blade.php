@extends('layouts.app')

@section('content')
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">{{$title}}</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                            <li class="breadcrumb-item active">Kasus baru kusta</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row justify-content-start mb-2">
                            <div class="col-md-10 d-flex justify-content-start gap-3">
                                {{-- {!! Form::select('induk_opd_id',$induk_opd_arr,"",['class'=>'form-control daerah', 'form'=>'storeForm','required'=>'required','placeholder'=>'Pilih SKPD', 'id'=>'induk_opd']) !!}
                            <select name="program_id" form="storeForm" id="program_id" class="form-control">
                                <option value="">Pilih Program</option>
                            </select>
                            <select name="kegiatan_id" form="storeForm" id="kegiatan_id" class="form-control">
                                <option value="">Pilih Kegiatan</option>
                            </select>
                            --}}
                                <select name="tahun" id="tahun" class="form-control">
                                    <option value="2024" {{ app('request')->input('year') == 2024 ? 'selected' : '' }}>
                                        2024
                                    </option>
                                    <option value="2023" {{ app('request')->input('year') == 2023 ? 'selected' : '' }}>
                                        2023
                                    </option>
                                </select>
                                <button class="btn btn-primary" id="filter">Submit</button>
                                <a type="button" class="btn btn-warning"
                                    href="{{ route('diabetes.report', ['year' => app('request')->input('year')]) }}"
                                    target='_blank'><i class="mdi mdi-note"></i>Report</a>
                            </div>
                            {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div>
                        </div>
                        {{-- <h4 class="card-title">Pengguna</h4> --}}
                        {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                        <div class="table-responsive">
                            <table id="data" class="table table-bordered dt-responsive"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead class="text-center">
                                    <tr>
                                        <th rowspan="3" style="vertical-align: middle">No</th>
                                        <th rowspan="3" style="vertical-align: middle">Desa</th>
                                        <th colspan="3">KUSTA (PB)</th>
                                        <th colspan="3">KUSTA (MB)</th>
                                        @role('Admin')
                                            <th rowspan="2">Lock data</th>
                                        @endrole
                                    </tr>
                                    <tr>
                                        <th colspan="1">Tahun</th>
                                        <th colspan="2">2022</th>
                                        <th colspan="1">Tahun</th>
                                        <th colspan="2">2021</th>
                                    </tr>
                                    <tr>
                                        <th colspan="1">JML PENDERITA BARUa</th>
                                        <th colspan="1">JML PENDERITA RFT</th>
                                        <th colspan="1">RFT RATE PB (%)</th>
                                        <th colspan="1">JML PENDERITA BARUb</th>
                                        <th colspan="1">JML PENDERITA RFT</th>
                                        <th colspan="1">RFT RATE MB (%)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @role('Admin')
                                        @php
                                            $Grandkusta_2022_baru = 0;
                                            $Grandkusta_2022_rft = 0;
                                            $Grandkusta_2021_baru = 0;
                                            $Grandkusta_2021_rft = 0;
                                        @endphp
                                        @foreach ($unit_kerja as $key => $item)
                                        <tr style='{{ $key % 2 == 0 ? 'background: #e9e9e9' : '' }}'>
                                            <td>{{ $key + 1 }}</td>
                                            <td>{{ $item->nama }}</td>
                                            <td>
                                                @php
                                                    $kusta_2022_baru = $item->unitKerjaAmbilPart2('filterTable67', app('request')->input('year'), 'kusta_2022_baru')['total'];
                                                    $Grandkusta_2022_baru += $kusta_2022_baru;
                                                    echo $kusta_2022_baru;
                                                @endphp
                                            </td>
                                            <td>
                                                @php
                                                    $kusta_2022_rft = $item->unitKerjaAmbilPart2('filterTable67', app('request')->input('year'), 'kusta_2022_rft')['total'];
                                                    $Grandkusta_2022_rft += $kusta_2022_rft;
                                                    echo  $kusta_2022_rft;
                                                @endphp
                                            </td>
                                            <td id="pb_rate_">
                                                {{$kusta_2022_baru>0 ? number_format(($kusta_2022_rft / $kusta_2022_baru) * 100, 2) . '%':0}}
                                            </td>
                                            <td>
                                                @php
                                                    $kusta_2021_baru = $item->unitKerjaAmbilPart2('filterTable67', app('request')->input('year'), 'kusta_2021_baru')['total'];
                                                    $Grandkusta_2021_baru += $kusta_2021_baru;
                                                    echo $kusta_2021_baru;
                                                @endphp
                                            </td>
                                            <td>
                                                @php
                                                    $kusta_2021_rft = $item->unitKerjaAmbilPart2('filterTable67', app('request')->input('year'), 'kusta_2021_rft')['total'];
                                                    $Grandkusta_2021_rft += $kusta_2021_rft;
                                                    echo  $kusta_2021_rft;
                                                @endphp
                                            </td>
                                            <td id="mb_rate_">
                                                {{$kusta_2021_baru>0?number_format(($kusta_2021_rft / $kusta_2021_baru) * 100, 2) . '%':0}}
                                            </td>
                                        </tr>
                                        @endforeach
                                        <tr>
                                            <th colspan="2">Jumlah</th>
                                            <th id="Grandkusta_2022_baru">{{  $Grandkusta_2022_baru }}</th>
                                            <th id="Grandkusta_2022_rft">{{ $Grandkusta_2022_rft  }}</th>
                                            <th id="PGrandKusta_2022">
                                                {{$Grandkusta_2022_rft > 0 && $Grandkusta_2022_baru > 0 ? number_format(($Grandkusta_2022_rft / $Grandkusta_2022_baru) * 100, 2) . '%' : 0}}
                                            </th>
                                            <th id="Grandkusta_2021_baru">{{ $Grandkusta_2021_baru }}</th>
                                            <th id="Grandkusta_2021_rft">{{ $Grandkusta_2021_rft  }}</th>
                                            <th id="PGrandKusta_2021">
                                                {{$Grandkusta_2021_rft > 0 && $Grandkusta_2021_baru > 0 ? number_format(($Grandkusta_2021_rft / $Grandkusta_2021_baru) * 100, 2) . '%' : 0}}
                                            </th>
                                        </tr>
                                    @endrole
                                    @role('Puskesmas|Pihak Wajib Pajak')
                                        @php
                                            $Grandkusta_2022_baru = 0;
                                            $Grandkusta_2022_rft = 0;
                                            $Grandkusta_2021_baru = 0;
                                            $Grandkusta_2021_rft = 0;
                                        @endphp
                                        @foreach ($desa as $key => $item)
                                            @if ($item->filterTable67(app('request')->input('year'), $item->id))
                                                <tr style='{{ $key % 2 == 0 ? 'background: #e9e9e9' : '' }}'>
                                                    <td>{{ $key + 1 }}</td>
                                                    <td>{{ $item->nama }}</td>
                                                    <td>
                                                        @php
                                                            $kusta_2022_baru = $item
                                                                ->filterTable67(
                                                                    app('request')->input('year'),
                                                                    $item->id,
                                                                )
                                                                ->kusta_2022_baru;
                                                            $Grandkusta_2022_baru += $kusta_2022_baru;
                                                        @endphp
                                                        <input type="number" name="kusta_2022_baru"
                                                            id="{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}"
                                                            value="{{ $kusta_2022_baru }}"
                                                            class="form-control data-input" style="border: none">
                                                    </td>
                                                    <td>
                                                        @php
                                                            $kusta_2022_rft = $item
                                                                ->filterTable67(
                                                                    app('request')->input('year'),
                                                                    $item->id,
                                                                )
                                                                ->kusta_2022_rft;
                                                            $Grandkusta_2022_rft += $kusta_2022_rft;
                                                        @endphp
                                                        {{-- {{ $totalIbuHamil }} --}}
                                                        <input type="number" name="kusta_2022_rft"
                                                            id="{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}"
                                                            value="{{ $kusta_2022_rft }}"
                                                            class="form-control data-input" style="border: none">
                                                    </td>
                                                    <td id="pb_rate_{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}">
                                                        {{$kusta_2022_baru?number_format(($kusta_2022_rft / $kusta_2022_baru) * 100, 2) . '%':0}}
                                                    </td>
                                                    <td>
                                                        @php
                                                            $kusta_2021_baru = $item
                                                                ->filterTable67(
                                                                    app('request')->input('year'),
                                                                    $item->id,
                                                                )
                                                                ->kusta_2021_baru;
                                                            $Grandkusta_2021_baru += $kusta_2021_baru;
                                                        @endphp
                                                        {{-- {{ $totalIbuHamil }} --}}
                                                        <input type="number" name="kusta_2021_baru"
                                                            id="{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}"
                                                            value="{{ $kusta_2021_baru }}"
                                                            class="form-control data-input" style="border: none">
                                                    </td>
                                                    <td>
                                                        @php
                                                            $kusta_2021_rft = $item
                                                                ->filterTable67(
                                                                    app('request')->input('year'),
                                                                    $item->id,
                                                                )
                                                                ->kusta_2021_rft;
                                                            $Grandkusta_2021_rft += $kusta_2021_rft;

                                                        @endphp
                                                        {{-- {{ $totalIbuHamil }} --}}
                                                        <input type="number" name="kusta_2021_rft"
                                                            id="{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}"
                                                            value="{{ $kusta_2021_rft }}"
                                                            class="form-control data-input" style="border: none">
                                                    </td>
                                                    <td id="mb_rate_{{ $item->filterTable67(app('request')->input('year'), $item->id)->id }}">
                                                        {{$kusta_2021_baru>0?number_format(($kusta_2021_rft / $kusta_2021_baru) * 100, 2) . '%':0}}
                                                    </td>
                                                </tr>
                                            @endif
                                        @endforeach
                                        <tr>
                                            <th colspan="2">Jumlah</th>
                                            <th id="Grandkusta_2022_baru">{{  $Grandkusta_2022_baru }}</th>
                                            <th id="Grandkusta_2022_rft">{{ $Grandkusta_2022_rft  }}</th>
                                            <th id="PGrandKusta_2022">
                                                {{$Grandkusta_2022_baru>0?number_format(($Grandkusta_2022_rft / $Grandkusta_2022_baru) * 100, 2) . '%':0}}
                                            </th>
                                            <th id="Grandkusta_2021_baru">{{ $Grandkusta_2021_baru }}</th>
                                            <th id="Grandkusta_2021_rft">{{ $Grandkusta_2021_rft  }}</th>
                                            <th id="PGrandKusta_2021">
                                                {{$Grandkusta_2021_baru>0?number_format(($Grandkusta_2021_rft / $Grandkusta_2021_baru) * 100, 2) . '%':0}}
                                            </th>
                                        </tr>
                                    @endrole
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->


    </div>

    <div class="modal fade" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="title">Tambah Program</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <input type="submit" value="Submit" class="btn btn-primary" id="submitButton" form="storeForm">
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>

    @push('scripts')
        <!-- Required datatable js -->
        <script src="{{ asset('assets/libs/datatables.net/js/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
        <!-- Buttons examples -->
        <script src="{{ asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js') }}"></script>
        <script src="{{ asset('assets/libs/jszip/jszip.min.js') }}"></script>
        <script src="{{ asset('assets/libs/pdfmake/build/pdfmake.min.js') }}"></script>
        <script src="{{ asset('assets/libs/pdfmake/build/vfs_fonts.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js') }}"></script>
        <!-- Responsive examples -->
        <script src="{{ asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js') }}"></script>
        <script src="{{ asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js') }}"></script>
    @endpush

    @push('scripts')
        <script>
            $('#data').on('input', '.data-input', function() {
                let name = $(this).attr('name');
                let value = $(this).val();
                let data = {};
                var url_string = window.location.href;
                var url = new URL(url_string);
                let params = url.searchParams.get("year");
                let id = $(this).attr('id');
                // let persen = $(this).parent().parent().find(`#persen${id}`);
                // let balita_dipantau = $(this).parent().parent().find(`#balita_dipantau${id}`);
                // let balita_sdidtk = $(this).parent().parent().find(`#balita_sdidtk${id}`);
                // let balita_mtbs = $(this).parent().parent().find(`#balita_mtbs${id}`);
                // let lahir_hidup_mati_LP = $(this).parent().parent().find(`#lahir_hidup_mati_LP${id}`);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    'type': 'POST',
                    'url': '{{ url($route) }}',
                    'data': {
                        'name': name,
                        'value': value,
                        'id': id,
                        'year': params
                    },
                    success: function(res) {
                        console.log(res);
                        $('#pb_rate_' + id).text(res.pb_rate_);
                        $('#mb_rate_' + id).text(res.mb_rate_);

                        $('#Grandkusta_2022_baru').text(res.Grandkusta_2022_baru);
                        $('#Grandkusta_2022_rft').text(res.Grandkusta_2022_rft);
                        $('#PGrandKusta_2022').text(res.PGrandKusta_2022);

                        $('#Grandkusta_2021_baru').text(res.Grandkusta_2021_baru);
                        $('#Grandkusta_2021_rft').text(res.Grandkusta_2021_rft);
                        $('#PGrandKusta_2021').text(res.PGrandKusta_2021);
                    }
                });
                // console.log(name, value, id);
            })



            $("#filter").click(function() {
                let year = $("#tahun").val();
                window.location.href = "{{ url($route) }}?year=" + year;
            })
        </script>
    @endpush
@endsection
