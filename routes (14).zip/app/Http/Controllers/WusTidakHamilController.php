<?php

namespace App\Http\Controllers;

use App\Models\Desa;
use App\Models\UnitKerja;
use App\Models\Wus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WusTidakHamilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $routeName = 'WusTidakHamil';
    protected $viewName = 'wus_tidak_hamil';
    protected $title = 'Wus Tidak Hamil';
    public function index(Request $request)
    {
        $unit_kerja = UnitKerja::all();
        // $desa = Desa::all();
        // foreach ($desa as $key => $value) {
        //     # code...
        //     Wus::create([
        //         'desa_id' => $value->id,
        //     ]);
        // }
        $data=[
            'route'=>$this->routeName,
            'title'=>$this->title,
            'unit_kerja' =>  $unit_kerja,
            'desa' => Auth::user()->unit_kerja?Auth::user()->unit_kerja->Desa()->get():Desa::all(),
        ];

        return view($this->viewName.'.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $wusTidakHamil = Wus::where('id', $request->id)->first();
        $wusTidakHamil->update([
            $request->name => $request->value,
        ]);
        $td1 = $wusTidakHamil->jumlah>0?number_format($wusTidakHamil->td1/$wusTidakHamil->jumlah * 100, 2):0;
        $td2 = $wusTidakHamil->jumlah>0?number_format($wusTidakHamil->td2/$wusTidakHamil->jumlah * 100, 2):0;
        $td3 = $wusTidakHamil->jumlah>0?number_format($wusTidakHamil->td3/$wusTidakHamil->jumlah * 100, 2):0;
        $td4 = $wusTidakHamil->jumlah>0?number_format($wusTidakHamil->td4/$wusTidakHamil->jumlah * 100, 2):0;
        $td5 = $wusTidakHamil->jumlah>0?number_format($wusTidakHamil->td5/$wusTidakHamil->jumlah * 100, 2):0;

        return response()->json([
            'status' => 'success',
            'td1' => $td1,
            'td2' => $td2,
            'td3' => $td3,
            'td4' => $td4,
            'td5' => $td5,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
