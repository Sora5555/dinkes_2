@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               <h4 class="mb-sm-0">{{$title}}</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Input Data</a></li>
                        <li class="breadcrumb-item active">{{$title}}</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row justify-content-start mb-2">
                        <div class="col-md-10 d-flex justify-content-around gap-3">
                            {{-- {!! Form::select('induk_opd_id',$induk_opd_arr,"",['class'=>'form-control daerah', 'form'=>'storeForm','required'=>'required','placeholder'=>'Pilih SKPD', 'id'=>'induk_opd']) !!}
                            <select name="program_id" form="storeForm" id="program_id" class="form-control">
                                <option value="">Pilih Program</option>
                            </select>
                            <select name="kegiatan_id" form="storeForm" id="kegiatan_id" class="form-control">
                                <option value="">Pilih Kegiatan</option>
                            </select>
                            --}}
                            <select name="tahun" id="tahun" class="form-control">
                                <option value="2024" {{app('request')->input('year') == 2024 ? "selected":""}}>2024</option>
                            </select> 
                            <button class="btn btn-primary" id="filter">Submit</button>
                        </div>
                        {{-- <div class="col-md-2">
                            <button class="btn btn-primary col-md-12 btn-tambah-program"><i class="mdi mdi-plus"></i> Tambah</button>
                        </div> --}}
                    </div>
                    {{-- <h4 class="card-title">Pengguna</h4> --}}
                    {{-- <p class="card-title-desc">DataTables has most features enabled by
                        default, so all you need to do to use it with your own tables is to call
                        the construction function: <code>$().DataTable();</code>.
                    </p> --}}
                    <div class="table-responsive">
                        <table id="data" class="table table-bordered dt-responsive" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="text-center">
                            <tr style="width: 100%">
                                <th rowspan="3">No</th>
                                @role("Admin")
                                <th rowspan="3">Puskesmas</th>
                                @endrole
                                @role("Puskesmas|Pihak Wajib Pajak")
                                <th rowspan="3">Desa</th>
                                @endrole
                                <th colspan="23">Usaha Kesehatan Gigi Sekolah (UKGS)</th>
                            </tr>
                            <tr>
                                <th rowspan="2">Jumlah SD/MI</th>
                                <th rowspan="2">Jumlah SD/MI dengan Sikat Gigi Massal</th>
                                <th rowspan="2">%</th>
                                <th rowspan="2">Jumlah SD/MI mendapat Yan. Gigi</th>
                                <th rowspan="2">%</th>
                                <th colspan="3">Jumlah Murid SD/MI</th>
                                <th colspan="6">Murid SD/MI Diperiksa</th>
                                <th colspan="3">Murid SD/MI Perlu Perawatan</th>
                                <th colspan="6">Murid SD/MI Mendapat Perawatan</th>
                            </tr>
                            <tr>
                                <th>L</th>
                                <th>P</th>
                                <th>L+P</th>
                                <th>L</th>
                                <th>%</th>
                                <th>P</th>
                                <th>%</th>
                                <th>L+P</th>
                                <th>%</th>
                                <th>L</th>
                                <th>P</th>
                                <th>L+P</th>
                                <th>L</th>
                                <th>%</th>
                                <th>P</th>
                                <th>%</th>
                                <th>L+P</th>
                                <th>%</th>
                            </tr>
                            </thead>
                            <tbody>
                                @role('Admin|superadmin')
                                @foreach ($unit_kerja as $key => $item)
                                
                                <tr style={{$key % 2 == 0?"background: gray":""}}>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sd')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sikat')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sd')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sikat')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sd')["total"] * 100, 2
                                        ):0}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_yan')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sd')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_yan')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'jumlah_sd')["total"] * 100, 2
                                        ):0}}</td>

                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_L')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"] * 100, 2
                                        ):0}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_P')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"] * 100, 2
                                        ):0}}</td>
                                  
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"]> 0?
                                        number_format(($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_L')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'diperiksa_P')["total"])
                                        /($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_L')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'sd_P')["total"]) * 100, 2
                                        ):0}}</td>

                                    
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_L')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"] * 100, 2
                                        ):0}}</td>
                                    
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_P')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"] > 0?
                                        number_format($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_P')["total"]
                                        /$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"] * 100, 2
                                        ):0}}</td>
                                  
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_L')["total"]}}</td>
                                    <td>{{$item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"]> 0?
                                        number_format(($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_L')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'dapat_P')["total"])
                                        /($item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_L')["total"] + $item->unitKerjaAmbil('filterGigiAnak', app('request')->input('year'), 'rawat_P')["total"]) * 100, 2
                                        ):0}}</td>

                                    
                                    
                                    
                                    
                                    
                                </tr>
                                @endforeach
                                @endrole
                                @role('Puskesmas|Pihak Wajib Pajak')
                                @foreach ($desa as $key => $item)
                                @if($item->filterPenyebabKematianIbu(app('request')->input('year')))
                                <tr style='{{$key % 2 == 0?"background: #e9e9e9":""}}'>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$item->nama}}</td>
                                    <td><input type="number" name="jumlah_sd" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->jumlah_sd}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td><input type="number" name="jumlah_sikat" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->jumlah_sikat}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="sikat{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->jumlah_sd>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->jumlah_sikat
                                        /$item->filterGigiAnak(app('request')->input('year'))->jumlah_sd * 100, 2):0}}</td>
                                    
                                    <td><input type="number" name="jumlah_yan" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->jumlah_yan}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    
                                    <td id="yan{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->jumlah_sd>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->jumlah_yan
                                        /$item->filterGigiAnak(app('request')->input('year'))->jumlah_sd * 100, 2):0}}</td>

                                    <td><input type="number" name="sd_L" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->sd_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td><input type="number" name="sd_P" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->sd_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="sd_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->sd_L + $item->filterGigiAnak(app('request')->input('year'))->sd_P}}</td>
                                    
                                    <td><input type="number" name="diperiksa_L" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->diperiksa_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="diperiksa_L{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->sd_L>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->diperiksa_L
                                        /$item->filterGigiAnak(app('request')->input('year'))->sd_L * 100, 2):0}}</td>

                                    <td><input type="number" name="diperiksa_P" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->diperiksa_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="diperiksa_P{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->sd_P>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->diperiksa_P
                                        /$item->filterGigiAnak(app('request')->input('year'))->sd_P * 100, 2):0}}</td>

                                    <td id="diperiksa_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->diperiksa_L + $item->filterGigiAnak(app('request')->input('year'))->diperiksa_P}}</td>
                                    <td id="persen_diperiksa_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->sd_P + $item->filterGigiAnak(app('request')->input('year'))->sd_L>0?
                                        number_format(( $item->filterGigiAnak(app('request')->input('year'))->diperiksa_L + $item->filterGigiAnak(app('request')->input('year'))->diperiksa_P)
                                        /($item->filterGigiAnak(app('request')->input('year'))->sd_L + $item->filterGigiAnak(app('request')->input('year'))->sd_P) * 100, 2):0}}</td>

                                    <td><input type="number" name="rawat_L" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->rawat_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td><input type="number" name="rawat_P" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->rawat_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="rawat_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->rawat_L + $item->filterGigiAnak(app('request')->input('year'))->rawat_P}}</td>
                                    
                                    <td><input type="number" name="dapat_L" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->dapat_L}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="dapat_L{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->rawat_L>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->dapat_L
                                        /$item->filterGigiAnak(app('request')->input('year'))->rawat_L * 100, 2):0}}</td>

                                    <td><input type="number" name="dapat_P" id="{{$item->filterGigiAnak(app('request')->input('year'))->id}}" value="{{$item->filterGigiAnak(app('request')->input('year'))->dapat_P}}" class="form-control data-input" style="border: none; width: 100%"></td>
                                    <td id="dapat_P{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->rawat_P>0?
                                        number_format($item->filterGigiAnak(app('request')->input('year'))->dapat_P
                                        /$item->filterGigiAnak(app('request')->input('year'))->rawat_P * 100, 2):0}}</td>

                                    <td id="dapat_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->dapat_L + $item->filterGigiAnak(app('request')->input('year'))->dapat_P}}</td>
                                    <td id="persen_dapat_LP{{$item->filterGigiAnak(app('request')->input('year'))->id}}">{{$item->filterGigiAnak(app('request')->input('year'))->rawat_P + $item->filterGigiAnak(app('request')->input('year'))->rawat_L>0?
                                        number_format(( $item->filterGigiAnak(app('request')->input('year'))->dapat_L + $item->filterGigiAnak(app('request')->input('year'))->dapat_P)
                                        /($item->filterGigiAnak(app('request')->input('year'))->rawat_L + $item->filterGigiAnak(app('request')->input('year'))->rawat_P) * 100, 2):0}}</td>



                                </tr>
                                  @endif
                                @endforeach
                                @endrole
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->


</div>

@push('scripts')
    <!-- Required datatable js -->
    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/libs/jszip/jszip.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/pdfmake.min.js')}}"></script>
    <script src="{{asset('assets/libs/pdfmake/build/vfs_fonts.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
    <!-- Responsive examples -->
    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')}}"></script>

@endpush

@push('scripts')
    <script>

        $('#data').on('input', '.data-input', function(){
		let name = $(this).attr('name');
		let value = $(this).val();
		let data = {};
        var url_string = window.location.href;
         var url = new URL(url_string);
        let params = url.searchParams.get("year");
        let id = $(this).attr('id');
        let sikat = $(this).parent().parent().find(`#sikat${id}`);
        let yan = $(this).parent().parent().find(`#yan${id}`);
        let diperiksa_L = $(this).parent().parent().find(`#diperiksa_L${id}`);
        let diperiksa_P = $(this).parent().parent().find(`#diperiksa_P${id}`);
        let diperiksa_LP = $(this).parent().parent().find(`#diperiksa_LP${id}`);
        let persen_diperiksa_LP = $(this).parent().parent().find(`#persen_diperiksa_LP${id}`);
        let sd_LP = $(this).parent().parent().find(`#sd_LP${id}`);
        
        let dapat_L = $(this).parent().parent().find(`#dapat_L${id}`);
        let dapat_P = $(this).parent().parent().find(`#dapat_P${id}`);
        let dapat_LP = $(this).parent().parent().find(`#dapat_LP${id}`);
        let persen_dapat_LP = $(this).parent().parent().find(`#persen_dapat_LP${id}`);
        let rawat_LP = $(this).parent().parent().find(`#rawat_LP${id}`);
        
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});

		$.ajax({
			'type' 	: 'POST',
			'url'	: '{{ route("GigiAnak.store") }}',
			'data'	: {'name' : name, 'value' : value, 'id': id, 'year': params},
			success	: function(res){
                sikat.text(`${res.sikat}`);
                yan.text(`${res.yan}`);
                diperiksa_L.text(`${res.diperiksa_L}`);
                diperiksa_P.text(`${res.diperiksa_P}`);
                diperiksa_LP.text(`${res.diperiksa_LP}`);
                persen_diperiksa_LP.text(`${res.persen_diperiksa_LP}`);
                sd_LP.text(`${res.sd_LP}`);
                dapat_L.text(`${res.dapat_L}`);
                dapat_P.text(`${res.dapat_P}`);
                dapat_LP.text(`${res.dapat_LP}`);
                persen_dapat_LP.text(`${res.persen_dapat_LP}`);
                rawat_LP.text(`${res.rawat_LP}`);
			}
		});
        console.log(name, value, id);
        })
        $("#filter").click(function(){
            let year = $("#tahun").val();
            window.location.href = "/JumlahKematianIbu?year="+year;


        })
    </script>
@endpush
@endsection