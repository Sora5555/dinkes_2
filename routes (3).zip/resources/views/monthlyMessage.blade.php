<h1>Hi {{$name}}</h1>
<p>Sudah masuk waktu jatuh tempo pembayaran, Jangan lupa untuk membayar</p>
<p>(abaikan bila sudah membayar)</p>