<?php

namespace App\Exports;

use Session;
use App\Models\Neonatal;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Events\AfterSheet;
use Illuminate\Support\Facades\Auth;

class NeonatalExport implements FromCollection, WithHeadings, WithEvents, WithCustomStartCell
{
    /**
    * @return \Illuminate\Support\Collection
    */

    /**
     * Return a collection of the data to be exported.
     */
    public function collection()
    {
        // Fetch the data you want to export

        $desa = Auth::user()->unit_kerja->Desa()->get();

        return $desa->map(function($desa) {
            return [
                'desa_name' => $desa->nama,
                'lahir_hidup_L' => $desa->filterKelahiran(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L : 'No Data',
                'lahir_hidup_P' => $desa->filterKelahiran(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P : '0',
                'lahir_hidup_LP' => $desa->filterKelahiran(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L : '0',
                
                'kn1_L' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->kn1_L : '0',
                'persen_kn1_L' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L > 0 ? number_format(($desa->filterNeonatal(Session::get('year'))->kn1_L / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L) * 100, 2) : 0 : '0',
                'kn1_P' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->kn1_P : '0',
                'persen_kn1_P' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P > 0 ?  number_format(($desa->filterNeonatal(Session::get('year'))->kn1_P / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P) * 100, 2) : 0 : '0',
                'kn1_LP' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterNeonatal(Session::get('year'))->kn1_L + $desa->filterNeonatal(Session::get('year'))->kn1_P : '0',
                'persen_kn1_LP' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P> 0?number_format(($desa->filterNeonatal(Session::get('year'))->kn1_L + $desa->filterNeonatal(Session::get('year'))->kn1_P)/(($desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P))* 100, 2) : 0 : '0',
                
                'kn_lengkap_L' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->kn_lengkap_L : '0',
                'persen_kn_lengkap_L' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L > 0 ?  number_format(($desa->filterNeonatal(Session::get('year'))->kn_lengkap_L / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L) * 100, 2) : 0 : '0',
                'kn_lengkap_P' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->kn_lengkap_P : '0',
                'persen_kn_lengkap_P' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P > 0 ?  number_format(($desa->filterNeonatal(Session::get('year'))->kn_lengkap_P / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P) * 100, 2) : 0 : '0',
                'kn_lengkap_LP' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterNeonatal(Session::get('year'))->kn_lengkap_L + $desa->filterNeonatal(Session::get('year'))->kn_lengkap_P : '0',
                'persen_kn_lengkap_LP' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P> 0?number_format(($desa->filterNeonatal(Session::get('year'))->kn_lengkap_L + $desa->filterNeonatal(Session::get('year'))->kn_lengkap_P)/(($desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P))* 100, 2) : 0 : '0',
                
                'hipo_L' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->hipo_L : '0',
                'persen_hipo_L' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L > 0 ? number_format(($desa->filterNeonatal(Session::get('year'))->hipo_L / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L) * 100, 2) : 0 : '0',
                'hipo_P' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterNeonatal(Session::get('year'))->hipo_P : '0',
                'persen_hipo_P' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P > 0 ?  number_format(($desa->filterNeonatal(Session::get('year'))->hipo_P / $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P) * 100, 2) : 0 : '0',
                'hipo_LP' => $desa->filterNeonatal(Session::get('year')) ? $desa->filterNeonatal(Session::get('year'))->hipo_L + $desa->filterNeonatal(Session::get('year'))->hipo_P : '0',
                'persen_hipo_LP' => $desa->filterNeonatal(Session::get('year')) ?  $desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P> 0?number_format(($desa->filterNeonatal(Session::get('year'))->hipo_L + $desa->filterNeonatal(Session::get('year'))->hipo_P)/(($desa->filterKelahiran(Session::get('year'))->lahir_hidup_L + $desa->filterKelahiran(Session::get('year'))->lahir_hidup_P))* 100, 2) : 0 : '0',
            ];
        });
    }
    public function headings(): array
    {
        return [
            ['Neonatal Data'],  // Main Title
            ['Desa', 'Jumlah Lahir Hidup', '', '', 'Kunjungan Neonatal 1 kali', '', '', '', '', '', 'Kunjungan Neonatal 3 kali (Kn Lengkap)', '', '', '', '', '', 'Bayi baru lahir yang diberikan screening Hipotiroid Konginetal', '', '', '', '', ''],
            ['', 'Laki Laki', 'Perempuan', 'Laki Laki + Perempuan', 'Laki Laki', '', 'Perempuan', '', 'Laki Laki + Perempuan', '', 'Laki Laki', '', 'Perempuan', '', 'Laki Laki + Perempuan', '', 'Laki Laki', '', 'Perempuan', '', 'Laki Laki + Perempuan', ''],
            ['', '', '', '', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', 'jumlah', '%', '', ]
        ];
    }

    public function startCell(): string
{
    return 'A1';  // Data will start here if header rows are set from A1 to A4
}

public function registerEvents(): array
{
    return [
        AfterSheet::class => function(AfterSheet $event) {
            $sheet = $event->sheet;

            // Merge the main title across the entire row
            $sheet->mergeCells('A1:P1');

            // Merge main header sections
            $sheet->mergeCells('B2:D2');  // 'Jumlah Lahir Hidup'
            $sheet->mergeCells('E2:J2');  // 'Kunjungan Neonatal 1 kali' 
            $sheet->mergeCells('K2:P2');  // 'Kunjungan Neonatal 3 kali (Kn Lengkap)'
            $sheet->mergeCells('Q2:V2');  // 'Hipotiroid'

            // Merge column headers for sub-sections
            $sheet->mergeCells('A3:A4');  // 'Desa'
            $sheet->mergeCells('B3:B4');  // 'Laki Laki (Jumlah Lahir Hidup)'
            $sheet->mergeCells('C3:C4');  // 'Perempuan (Jumlah Lahir Hidup)'
            $sheet->mergeCells('D3:D4');  // 'Laki Laki + Perempuan (Jumlah Lahir Hidup)'

            // Kunjungan Neonatal 1 kali headers
            $sheet->mergeCells('E3:F3');  // 'Laki Laki'
            $sheet->mergeCells('G3:H3');  // 'Perempuan'
            $sheet->mergeCells('I3:J3');  // 'Laki Laki + Perempuan'
            
            // Sub-headers for Kunjungan Neonatal 1 kali
            $sheet->setCellValue('E4', 'jumlah');
            $sheet->setCellValue('F4', '%');
            $sheet->setCellValue('G4', 'jumlah');
            $sheet->setCellValue('H4', '%');
            $sheet->setCellValue('I4', 'jumlah');
            $sheet->setCellValue('J4', '%');

            // Kunjungan Neonatal 3 kali (Kn Lengkap) headers
            $sheet->mergeCells('K3:L3');  // 'Laki Laki'
            $sheet->mergeCells('M3:N3');  // 'Perempuan'
            $sheet->mergeCells('O3:P3');  // 'Laki Laki + Perempuan'

            // Sub-headers for Kunjungan Neonatal 3 kali
            $sheet->setCellValue('K4', 'jumlah');
            $sheet->setCellValue('L4', '%');
            $sheet->setCellValue('M4', 'jumlah');
            $sheet->setCellValue('N4', '%');
            $sheet->setCellValue('O4', 'jumlah');
            $sheet->setCellValue('P4', '%');
            
            // Hipotiroid
            $sheet->mergeCells('Q3:R3');  // 'Laki Laki'
            $sheet->mergeCells('S3:T3');  // 'Perempuan'
            $sheet->mergeCells('U3:V3');  // 'Laki Laki + Perempuan'

            // Sub-headers for Kunjungan Neonatal 3 kali
            $sheet->setCellValue('Q4', 'jumlah');
            $sheet->setCellValue('R4', '%');
            $sheet->setCellValue('S4', 'jumlah');
            $sheet->setCellValue('T4', '%');
            $sheet->setCellValue('U4', 'jumlah');
            $sheet->setCellValue('V4', '%');

            // Apply styles
            $sheet->getStyle('A1:V4')->applyFromArray([
                'font' => ['bold' => true],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                    'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                ],
            ]);

            // Set column widths for readability
            $sheet->getColumnDimension('A')->setWidth(20);
            $sheet->getColumnDimension('B')->setWidth(15);
            $sheet->getColumnDimension('C')->setWidth(15);
            // Continue adjusting column widths as needed
        },
    ];
}

}
