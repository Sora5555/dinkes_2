<?php

namespace App\Http\Controllers;

use App\Models\Desa;
use App\Models\KematianNeonatal;
use App\Models\UnitKerja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KematianNeonatalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $routeName = 'KematianNeonatal';
    protected $viewName = 'kematian_neonatal';
    protected $title = 'Kematian Neonatal';
    public function index(Request $request)
    {
        $unit_kerja = UnitKerja::all();
        $desa = Desa::all();
        // foreach ($desa as $key => $value) {
        //     # code...
        //     KematianNeonatal::create([
        //         'desa_id' => $value->id,
        //     ]);
        // }
        $data=[
            'route'=>$this->routeName,
            'title'=>$this->title,
            'unit_kerja' =>  $unit_kerja,
            'desa' => Auth::user()->unit_kerja?Auth::user()->unit_kerja->Desa()->get():Desa::all(),
        ];

        return view($this->viewName.'.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $kematianNeonatal = KematianNeonatal::where('id', $request->id)->first();
        $kematianNeonatal->update([
            $request->name => $request->value,
        ]);
        $bayi_L = $kematianNeonatal->neo_L + $kematianNeonatal->post_neo_L;
        $bayi_P = $kematianNeonatal->neo_P + $kematianNeonatal->post_neo_P;
        $total_L = $kematianNeonatal->neo_L + $kematianNeonatal->post_neo_L + $kematianNeonatal->balita_L;
        $total_P = $kematianNeonatal->neo_P + $kematianNeonatal->post_neo_P + $kematianNeonatal->balita_P;
        $neo_LP = $kematianNeonatal->neo_P + $kematianNeonatal->neo_L;
        $post_neo_LP = $kematianNeonatal->post_neo_P + $kematianNeonatal->post_neo_L;
        $bayi_LP = $kematianNeonatal->post_neo_P + $kematianNeonatal->post_neo_L +  $kematianNeonatal->neo_P + $kematianNeonatal->neo_L;
        $balita_LP = $kematianNeonatal->balita_P + $kematianNeonatal->balita_L;
        $total_LP = $kematianNeonatal->balita_P + $kematianNeonatal->balita_L + $kematianNeonatal->post_neo_P + $kematianNeonatal->post_neo_L +  $kematianNeonatal->neo_P + $kematianNeonatal->neo_L;

        return response()->json([
            'message' => 'success',
            'bayi_L' => $bayi_L,
            'bayi_P' => $bayi_P,
            'total_L' => $total_L,
            'total_P' => $total_P,
            'neo_LP' => $neo_LP,
            'post_neo_LP' => $post_neo_LP,
            'bayi_LP' => $bayi_LP,
            'balita_LP' => $balita_LP,
            'total_LP' => $total_LP,
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
